
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;

public class loginValidate extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         int result1 = Integer.parseInt (request.getParameter("TeacherID"));
	 String result2 = request.getParameter("Password");				
                try {
			Class.forName("com.mysql.jdbc.Driver");
		 // loads driver
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/question_generator","root", ""); // gets a new connection
 
		PreparedStatement ps = con.prepareStatement("select teacher_id,password from teacher_credential where teacher_id=? and password=?");
		ps.setInt(1, result1);
		ps.setString(2, result2);
 
		ResultSet rs = ps.executeQuery();
 
		while (rs.next()) {
                     HttpSession session=request.getSession(true);   
                  String sql1 = ("SELECT teacher_name,address,phone,(SELECT faculty from teacher_credential where teacher_id = ?) FROM teacher WHERE teacher_id=?");
                 PreparedStatement st =con.prepareStatement(sql1);
                 st.setInt(1, result1);
                 st.setInt(2, result1);
                 
                ResultSet rrs = st.executeQuery();
                while(rrs.next()){
             
                 session.setAttribute("t_name",rrs.getString(1));
                 session.setAttribute("add",rrs.getString(2));
                  session.setAttribute("phone",rrs.getInt(3));
                    session.setAttribute("fac",rrs.getString(4));
                      session.setAttribute("t_id",result1);
                  
			 RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
			 rd.forward(request, response);
			
                }
		}
               request.setAttribute("error","Invalid Username or Password");
		RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
			 rd.forward(request, response);
		
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
    
