

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class LoginDao {

    public static boolean validate(int number, String pass) {
        boolean status = false;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/question_generator","root","");

            PreparedStatement ps = con.prepareStatement(
                    "select teacher_id,password from teacher_credential where teacher_id=? and password=?");
           
          
            ps.setInt(1, number);
            ps.setString(2, pass);
            ResultSet rs = ps.executeQuery();
            status = rs.next();
       
// --------------------------------------------  -----------------   -----------------   -----------------     
             
        }
 
        catch (Exception e) {
            System.out.println(e);
        }
        return status;
    }

}
