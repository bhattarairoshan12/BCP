/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Register extends HttpServlet {

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String lecturer = request.getParameter("lecturer_name");
        String password = request.getParameter("password");
        String dob = request.getParameter("dob");
        int phn = Integer.parseInt(request.getParameter("phone"));
        String address = request.getParameter("address");
        String dropd= request.getParameter("valuetxt");
        int id = (int) (Math.random() * 105);
        int regID = (int) (Math.random() * 34);
        
        if (RegisterDao.registerUser(id,password,dropd)) {
            try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/question_generator","root","");
            PreparedStatement ps = con.prepareStatement("insert into teacher(registration_id,teacher_id,teacher_name,address,phone,dob) values(?,?,?,?,?,?)");
                ps.setInt(1, regID);
                ps.setInt(2, id);
                ps.setString(3, lecturer);
                ps.setString(4, address);
                ps.setInt(5, phn);
                ps.setString(6, dob);
                ps.executeUpdate();
            } catch (SQLException | ClassNotFoundException e2 ) {
            System.out.println(e2);}
            
            out.print("<script> alert('User Registered Successfully');</script>");
//            out.print("<h5 style='color:green'> User Registered Successfully </h5>");
            RequestDispatcher rd = request.getRequestDispatcher("login_admin.jsp");
            rd.forward(request, response);
        } else {
            out.print("<h5 style='color:red'>Sorry, registration failed</h5>");
            RequestDispatcher rd = request.getRequestDispatcher("login_admin.jsp");
            rd.include(request, response);
        }

        out.close();
    }
}
