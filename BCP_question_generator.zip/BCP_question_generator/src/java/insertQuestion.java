/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.mysql.cj.Session;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Lenovo
 */
public class insertQuestion extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         String result3 = request.getParameter("Questions");
	 int result4 = Integer.parseInt(request.getParameter("valuetxt"));
        
        
                try {
			Class.forName("com.mysql.jdbc.Driver");
                         String n = request.getSession(false).getAttribute("fac").toString();
		 // loads driver
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/question_generator","root", ""); // gets a new connection
 
		PreparedStatement ps = con.prepareStatement("INSERT INTO questions(question,mark,faculty_name) VALUES(?,?,?)");
		ps.setString(1, result3);
		ps.setInt(2, result4);
                ps.setString(3,n);
 		ps.executeUpdate();
                 RequestDispatcher rd=request.getRequestDispatcher("upload_question.jsp");
			 rd.forward(request, response);
                }
                catch(ClassNotFoundException | SQLException e){}
    }


}
