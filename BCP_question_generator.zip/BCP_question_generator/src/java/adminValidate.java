/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Lenovo
 */
public class adminValidate extends HttpServlet {



    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
              int result1 = Integer.parseInt (request.getParameter("admID"));
              
	 String result2 = request.getParameter("password");				
                try {
			Class.forName("com.mysql.jdbc.Driver");
		 // loads driver
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/question_generator","root", ""); // gets a new connection
 
		PreparedStatement ps = con.prepareStatement("select admin_id,password from admin where admin_id=? and password=?");
		ps.setInt(1, result1);
		ps.setString(2, result2);
 
		 ResultSet i = ps.executeQuery();           
                if(i.next()){
		RequestDispatcher rd=request.getRequestDispatcher("admin_home.jsp");
			 rd.forward(request, response);
                }
                else{
                request.setAttribute("error","Invalid Username or Password");
		RequestDispatcher rd=request.getRequestDispatcher("login_admin.jsp");
			 rd.forward(request, response);
                }
		
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    
    }

    
  
}
