
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RegisterDao {
    public static boolean registerUser(int id,String pass,String fac) {
        boolean status = false;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/question_generator","root","");

            PreparedStatement ps = con.prepareStatement(
                   "insert into teacher_credential(teacher_id,password,faculty) values(?,?,?)");
            
 
            ps.setInt(1, id);
            ps.setString(2, pass);
            ps.setString(3, fac);
  
            int i = ps.executeUpdate();
            if (i > 0) {
                status = true;
            }

        } catch (SQLException | ClassNotFoundException e) {
            System.out.println(e);
        }

         return status;
    }
}
