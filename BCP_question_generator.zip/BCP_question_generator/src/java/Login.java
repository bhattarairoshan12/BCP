
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {"/Login"})
public class Login extends HttpServlet {

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        int userName = Integer.parseInt(request.getParameter("admID"));
        String password = request.getParameter("password");

        if (LoginDao.validate(userName, password)) {
            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/question_generator", "root", "");
                PreparedStatement pst = con.prepareStatement(
               "SELECT teacher_name,address,phone,faculty FROM teacher where teacher_id=?");
                pst.setInt(1,userName);
             ResultSet rst = pst.executeQuery();
        while (rst.next()) {
         HttpSession session = request.getSession();
          session.setAttribute("name", rst.getString(1));
            session.setAttribute("address", rst.getString(2));
           session.setAttribute("phone", rst.getInt(3));
            session.setAttribute("faculty", rst.getString(4));
            session.setAttribute("userid",userName);
           }
            RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
            rd.forward(request, response);
             
        }
            catch (SQLException ex) {
                Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else {
            request.setAttribute("error","Sorry username or password error");
            RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
            rd.include(request, response);
        }

        out.close();
    }
}
